<?php return array('dependencies' => array(), 'version' => '232e5e26705a7fc126e8');
