<?php return array('dependencies' => array(), 'version' => '9e367966cff0f24fe853');
