<?php return array('dependencies' => array(), 'version' => '2efcefa91d08716b7ee4');
