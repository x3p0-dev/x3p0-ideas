<?php return array('dependencies' => array(), 'version' => '8ac81a00c7cc56d2b963');
