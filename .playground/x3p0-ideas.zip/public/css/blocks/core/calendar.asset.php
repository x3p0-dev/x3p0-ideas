<?php return array('dependencies' => array(), 'version' => '9ebc7cad7fbc85ba59ef');
