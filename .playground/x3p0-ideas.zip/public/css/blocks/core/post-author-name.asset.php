<?php return array('dependencies' => array(), 'version' => 'b3313ed63b95e9370149');
