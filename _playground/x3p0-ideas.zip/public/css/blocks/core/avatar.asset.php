<?php return array('dependencies' => array(), 'version' => '31367da69c544d4f496b');
