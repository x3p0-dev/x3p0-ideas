<?php return array('dependencies' => array(), 'version' => 'db28e84e2004784f878a');
