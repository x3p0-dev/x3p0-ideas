<?php return array('dependencies' => array(), 'version' => 'e97525e57b1a8acebdb1');
