<?php return array('dependencies' => array(), 'version' => '608f7d9b8d0bc1131d41');
