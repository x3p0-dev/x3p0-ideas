<?php return array('dependencies' => array(), 'version' => '3b62398e651a7d265346');
