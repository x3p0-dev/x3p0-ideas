<?php return array('dependencies' => array(), 'version' => '41f0de1a0c85f6054362');
