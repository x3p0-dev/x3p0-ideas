<?php return array('dependencies' => array(), 'version' => 'd67e2de68267756b9314');
