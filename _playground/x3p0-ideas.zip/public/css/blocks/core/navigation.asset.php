<?php return array('dependencies' => array(), 'version' => '898902788183189baf8d');
