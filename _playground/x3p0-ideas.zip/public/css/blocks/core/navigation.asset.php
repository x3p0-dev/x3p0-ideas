<?php return array('dependencies' => array(), 'version' => 'ee3a20b2f535943ab19f');
