<?php return array('dependencies' => array(), 'version' => 'e12eaca9b0b32a94d29b');
