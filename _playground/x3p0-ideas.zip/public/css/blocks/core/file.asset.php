<?php return array('dependencies' => array(), 'version' => '2b30674ebeb78f104073');
