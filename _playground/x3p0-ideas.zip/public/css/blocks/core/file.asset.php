<?php return array('dependencies' => array(), 'version' => '55dc7bf1cf599b577a1f');
