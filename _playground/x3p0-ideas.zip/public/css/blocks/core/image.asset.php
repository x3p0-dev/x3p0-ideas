<?php return array('dependencies' => array(), 'version' => '82651c7d115779941874');
