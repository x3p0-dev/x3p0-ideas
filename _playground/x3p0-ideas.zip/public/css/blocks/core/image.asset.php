<?php return array('dependencies' => array(), 'version' => '4df3c1976dcb8b52fdcd');
