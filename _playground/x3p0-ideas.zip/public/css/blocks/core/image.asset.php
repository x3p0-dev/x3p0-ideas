<?php return array('dependencies' => array(), 'version' => '85216c95f335505dea2a');
