<?php return array('dependencies' => array(), 'version' => '5c8f1d8bc0d7474601c2');
