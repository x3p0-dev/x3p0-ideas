<?php return array('dependencies' => array(), 'version' => '8532a60be149f19c197a');
