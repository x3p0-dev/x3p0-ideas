<?php return array('dependencies' => array(), 'version' => '3e4e843c580ad2482bc2');
