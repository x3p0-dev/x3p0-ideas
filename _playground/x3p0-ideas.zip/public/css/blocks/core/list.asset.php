<?php return array('dependencies' => array(), 'version' => '7ceacd0a8900914666fc');
