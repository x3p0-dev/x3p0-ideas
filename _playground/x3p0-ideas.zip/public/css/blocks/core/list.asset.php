<?php return array('dependencies' => array(), 'version' => '86b0d5d517a08445b9f9');
