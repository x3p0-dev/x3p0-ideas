<?php return array('dependencies' => array(), 'version' => 'c6dc1ad23b024fddd12a');
