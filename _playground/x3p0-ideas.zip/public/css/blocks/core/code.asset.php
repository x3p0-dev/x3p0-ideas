<?php return array('dependencies' => array(), 'version' => 'ac4d823e6f84423385d8');
