<?php return array('dependencies' => array(), 'version' => '3280532c3f3a37b47ad1');
