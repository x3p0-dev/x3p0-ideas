<?php return array('dependencies' => array(), 'version' => '5fa768259746aea5ffa5');
