<?php return array('dependencies' => array(), 'version' => 'e188320345a0ab897766');
