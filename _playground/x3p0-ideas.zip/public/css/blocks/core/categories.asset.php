<?php return array('dependencies' => array(), 'version' => 'aadd0e2fd1e19b6fe197');
