<?php return array('dependencies' => array(), 'version' => 'c340a5a78acddf245768');
