<?php return array('dependencies' => array(), 'version' => '4b651a6aa533c79998da');
