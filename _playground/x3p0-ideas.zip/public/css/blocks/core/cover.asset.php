<?php return array('dependencies' => array(), 'version' => 'fe88c2cadc6b3e71b58e');
