<?php return array('dependencies' => array(), 'version' => 'bde04241db7fbb5d76a5');
