<?php return array('dependencies' => array(), 'version' => 'e009e7f626bc7428828e');
