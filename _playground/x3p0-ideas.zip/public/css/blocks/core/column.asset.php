<?php return array('dependencies' => array(), 'version' => '55364cbc952bffd31bab');
