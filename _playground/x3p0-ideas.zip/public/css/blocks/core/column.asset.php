<?php return array('dependencies' => array(), 'version' => '2ef3373fc9888d21f2c1');
