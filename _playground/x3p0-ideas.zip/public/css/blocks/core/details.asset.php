<?php return array('dependencies' => array(), 'version' => '57b189cdd3ea5fb5629c');
