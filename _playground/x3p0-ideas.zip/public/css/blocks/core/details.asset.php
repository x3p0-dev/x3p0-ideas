<?php return array('dependencies' => array(), 'version' => 'd5234b5a324e6616d599');
