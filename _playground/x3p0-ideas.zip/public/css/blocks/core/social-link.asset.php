<?php return array('dependencies' => array(), 'version' => '96447dffbbe4bf980421');
