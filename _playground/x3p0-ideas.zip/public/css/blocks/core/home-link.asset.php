<?php return array('dependencies' => array(), 'version' => '90e604709987c7e76449');
