<?php return array('dependencies' => array(), 'version' => '2364c2f5960867699a13');
