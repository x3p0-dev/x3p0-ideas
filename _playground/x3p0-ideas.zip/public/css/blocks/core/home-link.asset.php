<?php return array('dependencies' => array(), 'version' => '42fb25955b9d9bda9d34');
