<?php return array('dependencies' => array(), 'version' => '0d3785ddbfc8f658eb10');
