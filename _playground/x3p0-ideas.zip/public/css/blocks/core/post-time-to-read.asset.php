<?php return array('dependencies' => array(), 'version' => 'f8123944f95fe565509a');
