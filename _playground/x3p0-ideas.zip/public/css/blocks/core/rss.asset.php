<?php return array('dependencies' => array(), 'version' => '8579c6c1706f2d5be799');
