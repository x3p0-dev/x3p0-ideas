<?php return array('dependencies' => array(), 'version' => '0f6bbf6ebf7126072e21');
