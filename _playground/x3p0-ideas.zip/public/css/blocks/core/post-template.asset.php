<?php return array('dependencies' => array(), 'version' => 'cac322606c9abe7d0e50');
