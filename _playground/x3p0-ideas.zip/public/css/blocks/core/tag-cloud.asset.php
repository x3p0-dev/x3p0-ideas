<?php return array('dependencies' => array(), 'version' => '6d6f255c0c00ddfb5705');
