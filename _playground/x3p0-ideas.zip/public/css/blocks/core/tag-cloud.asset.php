<?php return array('dependencies' => array(), 'version' => 'f4400ee8fd55a45821a9');
