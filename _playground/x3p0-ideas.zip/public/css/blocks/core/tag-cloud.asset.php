<?php return array('dependencies' => array(), 'version' => '97bdafe8ee2a020a2b67');
