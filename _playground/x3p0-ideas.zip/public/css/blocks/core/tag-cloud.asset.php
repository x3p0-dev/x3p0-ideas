<?php return array('dependencies' => array(), 'version' => '026ac2cc06b1dfca47c5');
