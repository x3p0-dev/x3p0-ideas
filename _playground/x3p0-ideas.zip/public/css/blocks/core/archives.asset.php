<?php return array('dependencies' => array(), 'version' => '288801da9d55441f4292');
