<?php return array('dependencies' => array(), 'version' => '2a28b7d6ed78217b7bc7');
