<?php return array('dependencies' => array(), 'version' => 'e32d4df0116e5d9c9b95');
