<?php return array('dependencies' => array(), 'version' => '13a69cf00ba83a9a2f44');
