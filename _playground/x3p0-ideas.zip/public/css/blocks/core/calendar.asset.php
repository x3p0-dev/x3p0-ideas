<?php return array('dependencies' => array(), 'version' => '1e96f8bd886937fec8e9');
