<?php return array('dependencies' => array(), 'version' => '63d36dbf4254621f8f82');
