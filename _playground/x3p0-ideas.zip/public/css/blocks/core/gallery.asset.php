<?php return array('dependencies' => array(), 'version' => 'c5ef9148610b15be8b97');
