<?php return array('dependencies' => array(), 'version' => '389c65d5a999afe85e12');
