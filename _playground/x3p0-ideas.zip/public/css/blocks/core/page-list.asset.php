<?php return array('dependencies' => array(), 'version' => '1b36cd00c95a2eb30e9d');
