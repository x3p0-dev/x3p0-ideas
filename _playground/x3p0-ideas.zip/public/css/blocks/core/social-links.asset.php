<?php return array('dependencies' => array(), 'version' => 'b10be322dcda10241f5d');
