<?php return array('dependencies' => array(), 'version' => '7dba2ee6e8c55c94defa');
