<?php return array('dependencies' => array(), 'version' => 'd0eebd306713c7f73fb8');
