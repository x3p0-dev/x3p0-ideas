<?php return array('dependencies' => array(), 'version' => 'bbdda9cf59366a536107');
