<?php return array('dependencies' => array(), 'version' => '1de406a4ff48cfcc6c21');
