<?php return array('dependencies' => array(), 'version' => 'b86cc4b9389f5c78dc65');
