<?php return array('dependencies' => array(), 'version' => 'd8762dcbe2c7233c42e7');
