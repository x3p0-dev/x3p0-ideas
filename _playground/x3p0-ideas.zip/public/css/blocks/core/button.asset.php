<?php return array('dependencies' => array(), 'version' => 'a8bc4ef7bad3d8dcf66a');
