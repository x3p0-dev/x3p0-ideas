<?php return array('dependencies' => array(), 'version' => 'abd14112a44cb21fe630');
