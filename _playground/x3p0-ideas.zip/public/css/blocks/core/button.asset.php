<?php return array('dependencies' => array(), 'version' => '9c9f181b9610963486f3');
