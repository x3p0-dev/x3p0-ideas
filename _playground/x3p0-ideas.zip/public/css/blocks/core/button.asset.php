<?php return array('dependencies' => array(), 'version' => '80c5cae2872d5c18ad6a');
