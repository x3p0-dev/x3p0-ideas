<?php return array('dependencies' => array(), 'version' => '54bfac1c6732359cb28c');
