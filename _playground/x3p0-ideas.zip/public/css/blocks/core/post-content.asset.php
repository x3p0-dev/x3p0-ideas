<?php return array('dependencies' => array(), 'version' => '84d0cf22fdfc78994e51');
