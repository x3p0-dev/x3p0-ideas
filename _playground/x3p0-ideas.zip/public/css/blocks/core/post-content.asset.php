<?php return array('dependencies' => array(), 'version' => '7af26adad9fd91e33ec6');
