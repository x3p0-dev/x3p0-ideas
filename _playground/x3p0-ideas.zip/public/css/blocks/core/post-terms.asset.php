<?php return array('dependencies' => array(), 'version' => '3b605fe679f9fcea33a1');
