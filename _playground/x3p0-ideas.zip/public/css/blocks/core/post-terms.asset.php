<?php return array('dependencies' => array(), 'version' => 'ee50179a216884c91513');
