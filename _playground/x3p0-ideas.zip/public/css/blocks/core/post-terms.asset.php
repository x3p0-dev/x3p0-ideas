<?php return array('dependencies' => array(), 'version' => '50ead77366b26cb5694b');
