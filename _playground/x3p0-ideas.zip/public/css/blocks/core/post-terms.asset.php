<?php return array('dependencies' => array(), 'version' => '1414738564b3c40ffe69');
