<?php return array('dependencies' => array(), 'version' => '821d67974c4624d1e01a');
