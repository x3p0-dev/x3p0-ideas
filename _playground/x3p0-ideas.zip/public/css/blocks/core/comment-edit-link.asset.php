<?php return array('dependencies' => array(), 'version' => 'b456d7f03bd7cd5b6bc1');
