<?php return array('dependencies' => array(), 'version' => '2871bd77a33b8b5a67d2');
