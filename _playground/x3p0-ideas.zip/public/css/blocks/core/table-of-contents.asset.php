<?php return array('dependencies' => array(), 'version' => 'bb4805c58bdf3104f7ff');
