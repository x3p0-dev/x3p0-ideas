<?php return array('dependencies' => array(), 'version' => '8098123ead7ab60c1f53');
