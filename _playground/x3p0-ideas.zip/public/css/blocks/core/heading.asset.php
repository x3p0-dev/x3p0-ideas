<?php return array('dependencies' => array(), 'version' => '4ad183505602a7b56f73');
