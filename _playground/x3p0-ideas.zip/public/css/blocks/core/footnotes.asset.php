<?php return array('dependencies' => array(), 'version' => '2e4667ae08d095ac0e85');
