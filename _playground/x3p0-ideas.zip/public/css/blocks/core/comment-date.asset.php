<?php return array('dependencies' => array(), 'version' => 'd1423fd8f96bd8208dca');
