<?php return array('dependencies' => array(), 'version' => 'b40cb9eb9e2135ddc375');
