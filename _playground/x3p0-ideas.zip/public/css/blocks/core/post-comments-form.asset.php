<?php return array('dependencies' => array(), 'version' => 'c0dae11c64d20095814b');
