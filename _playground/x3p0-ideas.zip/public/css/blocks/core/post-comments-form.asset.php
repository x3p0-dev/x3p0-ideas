<?php return array('dependencies' => array(), 'version' => 'b0c79a4ccd3b270f3028');
