<?php return array('dependencies' => array(), 'version' => '9f50074be314bb91f1cc');
