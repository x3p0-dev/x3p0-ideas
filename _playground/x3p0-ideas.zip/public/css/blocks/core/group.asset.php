<?php return array('dependencies' => array(), 'version' => '4e96828073948ebd5431');
