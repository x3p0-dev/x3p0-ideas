<?php return array('dependencies' => array(), 'version' => '6659f0bc2ae659b2b6bb');
