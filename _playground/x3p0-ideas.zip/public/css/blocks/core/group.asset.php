<?php return array('dependencies' => array(), 'version' => 'a5e05337eb0c2f788f85');
