<?php return array('dependencies' => array(), 'version' => '62abe153bfc006dec6c3');
