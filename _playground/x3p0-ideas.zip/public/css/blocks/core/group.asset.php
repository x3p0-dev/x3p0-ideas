<?php return array('dependencies' => array(), 'version' => '3a657d74b4e2f6aa56c6');
