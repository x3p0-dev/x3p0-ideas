<?php return array('dependencies' => array(), 'version' => '094f0d8e92fa43b9dd9a');
