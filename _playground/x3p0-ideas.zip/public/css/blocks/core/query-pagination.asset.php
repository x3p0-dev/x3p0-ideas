<?php return array('dependencies' => array(), 'version' => '7694102a0f7ade975287');
