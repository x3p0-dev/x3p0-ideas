<?php return array('dependencies' => array(), 'version' => '425d1093767dab8478a2');
