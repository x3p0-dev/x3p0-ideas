<?php return array('dependencies' => array(), 'version' => 'a339b597b47c917bb440');
