<?php return array('dependencies' => array(), 'version' => '8c5b220bf6f482881a90');
