<?php return array('dependencies' => array(), 'version' => '85562ccb50f72f6b57d2');
