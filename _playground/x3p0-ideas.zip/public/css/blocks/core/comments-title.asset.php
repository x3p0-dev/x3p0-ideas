<?php return array('dependencies' => array(), 'version' => '2b69786fe1bbb294fbdb');
