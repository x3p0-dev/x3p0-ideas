<?php return array('dependencies' => array(), 'version' => '41b6fc73001a226b0b07');
