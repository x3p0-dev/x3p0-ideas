<?php return array('dependencies' => array(), 'version' => 'e9882a6a91ace2a3ac43');
