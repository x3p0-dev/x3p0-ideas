<?php return array('dependencies' => array(), 'version' => '10e95646745a39c582df');
