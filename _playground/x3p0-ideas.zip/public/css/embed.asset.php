<?php return array('dependencies' => array(), 'version' => '87b8312df1b65278bd8d');
