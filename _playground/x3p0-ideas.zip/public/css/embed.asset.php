<?php return array('dependencies' => array(), 'version' => '24e80f40312a46d2c968');
