<?php return array('dependencies' => array(), 'version' => '588d50f621a3473ce405');
