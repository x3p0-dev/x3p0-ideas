<?php return array('dependencies' => array(), 'version' => 'e54da4298f4e51e33cc9');
