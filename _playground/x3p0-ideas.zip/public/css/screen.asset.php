<?php return array('dependencies' => array(), 'version' => 'ee4eeb52b0b510cce77e');
