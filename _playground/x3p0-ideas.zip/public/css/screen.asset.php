<?php return array('dependencies' => array(), 'version' => '9b1e6c9a57c954bf262d');
