<?php return array('dependencies' => array(), 'version' => '0cf45703d5c2f964ca98');
