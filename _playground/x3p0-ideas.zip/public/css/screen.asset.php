<?php return array('dependencies' => array(), 'version' => '87e06f8c9d8aef17a4c3');
