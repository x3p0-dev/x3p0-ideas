<?php return array('dependencies' => array(), 'version' => 'd9ed47609206c0db0053');
