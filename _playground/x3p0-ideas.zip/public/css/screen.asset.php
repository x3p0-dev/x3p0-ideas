<?php return array('dependencies' => array(), 'version' => 'aaba82f8ee6322104b40');
