<?php return array('dependencies' => array(), 'version' => '69bfc8771e29306cfe11');
