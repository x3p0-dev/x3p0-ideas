<?php return array('dependencies' => array(), 'version' => '811f85f4ddc85513511b');
